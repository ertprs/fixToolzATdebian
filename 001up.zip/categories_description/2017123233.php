<b>Caracteristici:</b><br><br>
Material furca: fonta pana la 10 mm.<br>
Finisare: vopsire (culoare neagra).<br>
capul pivotant prezinta o combinatie specifica traficului greu din rulmenti cu role conice si rulmenti axiali.<br>
Niplurile de ungere sunt prezente atat pe capul pivotant, cat si pe roata.<br>
Conform standardelor europene EN 12532/12533.<br><br>

<b>Utilitate:</b><br><br>
Fabrici de masini.<br>
Sectorul petrochimic.<br>
Dispozitive de manipulare pentru materiale grele.<br>