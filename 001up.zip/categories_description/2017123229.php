<b>Caracteristici:</b><br><br>
Material furca: otel pana la 30 mm.<br>
Finisare: vopsire (culoare neagra).<br>
Capul pivotant prezinta o combinatie specifica traficului greu, din rulmenti cu role conice care permit remorcarea usoara a fortelor laterale.<br>
Niplurile de ungere sunt prezente atat pe capul pivotant, cat si pe roata.<br>
Conform standardelor europene EN 12532/12533.<br><br>

<b>Utilitate:</b><br><br>
Macarale pentru poduri.<br>
Aviatie.<br>
Fortele armate. <br>
Porturi.<br>
