<b>Caracteristici:</b><br><br>
Material furca: otel sudat pana la 6 mm.<br>
Finisare furca: zincare pasivizata.<br>
Capul pivotant prezinta sina dubla pentru bile pentru a asigura durabilitatea si longevitatea rotilor.<br>
Conform standardelor europene: EN 12532.<br><br>

<b>Utilitate:</b><br><br>
Orice mediu industrial din industria metalurgica si chimica, pentru manipularea materialelor in fabrici, servicii publice, carucioare mecanice etc.<br>
	