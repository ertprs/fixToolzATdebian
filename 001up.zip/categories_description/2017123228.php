<b>Caracteristici:</b><br><br>
Material furca: otel pana la 4.5 mm.<br>
Finisare furca: zincare.<br>
Capul pivotant prezinta rulmenti cu role pentru a suporta cu usurinta eforturile axiale<br>
niplurile de ungere sunt prezente pe toata suprafata furcii.<br>
Conform standardelor europene EN 12532/12533.<br><br>

<b>Utilitate:</b><br><br>
Orice mediu industrial de trafic greu unde este des intalnit impactul vertical.<br>
