<b>Caracteristici:</b><br><br>
Material furca: otel presat pana la 5 mm.<br>
Finisare furca: cromare dubla cu rezistenta sporita la rugina.<br>
Capul pivotant este etansat si nu permite intrarea prafului.<br>
Conform standardelor europene EN 12532.<br><br>

<b>Utilitate:</b><br><br>
Orice mediu industrial din industria metalurgica si chimica, pentru manipularea materialelor in fabrici, transportul echipamentului greu, carucioare industriale etc.<br>
