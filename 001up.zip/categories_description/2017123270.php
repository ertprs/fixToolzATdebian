<b>Caracteristici:</b><br><br>
Material furca: otel presat de inalta rezistenta.<br>
Finisare furca: zincare.<br>
Capul pivotant prezinta rulmenti dubli.<br>
Conform standardelor europene: EN 12532.<br><br>

<b>Utilitate:</b><br><br>
Carucioare si containere pe roti de tipul containerelor de deseuri, containerelor de transport, carucioarelor pentru transportat unelte, carucioarelor pentru magazine etc.<br>
