<b>Caracteristici:</b><br><br>
Material furca: otel inoxidabil presat de inalta calitate (AISI 304) pana la 3 mm.<br>
Otelul inoxidabil din care este facuta furca prezinta rezistenta inalta la coroziune, benzina, motorina, uleiuri si grasimi.<br>
Conform standardelor europene EN 12530/12532.<br><br>

<b>Utilitate:</b><br><br>
Mediile industriale specifice industriei farmaceutice si alimentare, in special pentru tipul activitatilor de procesare si transport alimentar, catering etc.<br>
	