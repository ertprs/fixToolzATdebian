<b>Caracteristici:</b><br><br>
Material furca: otel sudat 12 mm.<br>
Finisare furca: zincare si acoperire cu vopsea neagra.<br>
Dotate cu suspensii cu arc, foarte rezistente.<br>
prezinta caracteristici elastice pana la greutatea de 800 kg. <br>
Conform standardelor europene EN 12532/12533.<br><br>

<b>Utilitate:</b><br><br>
Mediile industriale care implica socuri, coliziuni sau rulari pe suprafete excesiv de neregulate.<br>

