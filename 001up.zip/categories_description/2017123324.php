<b>Caracteristici:</b><br><br>
Material furca: otel inoxidabil presat de inalta calitate (AISI 304) pana la 2 mm.<br>
Otelul inoxidabil din care este facuta furca prezinta rezistenta inalta la coroziune, benzina, motorina, uleiuri si grasimi.<br>
Conform standardelor europene EN 12530/12532.<br><br>

<b>Utilitate:</b><br><br>
Mediile industriale specifice industriei farmaceutice si alimentare, de tipul echipamentelor pentru catering, utilajelor de transport alimentar, carucioarelor pentru spalatorii etc.
