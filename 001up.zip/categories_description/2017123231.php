<b>Caracteristici:</b><br><br>
Material furca: otel sudat pana la 8 mm.<br>
Finisare: vopsire (culoare neagra).<br>
Capul pivotant prezinta o combinatie de rulmenti axiali si rulmenti cu role conice, fiind ideal pentru atat pentru suportarea sarcinilor axiale, cat si a sarcinilor radiale.<br>
Niplurile de ungere sunt prezente atat pe capul pivotant, cat si pe roata.<br>
Conform standardelor europene EN 12532/12533.<br><br>

<b>Utilitate:</b><br><br>
Carucioare mecanice.<br>
Carucioare de transportat marfa.<br>
Carucioare folosite in serviciile publice.<br>
Industria metalurgica si chimica.<br>