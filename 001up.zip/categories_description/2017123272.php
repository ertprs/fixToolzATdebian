<b>Caracteristici:</b><br><br>
Material furca: otel presat pana la 4 mm.<br>
Finisare furca: zincare.<br>
Capul pivotant prezinta rulmenti dubli.<br>
Conform standardelor europene EN 12532.<br><br>

<b>Utilitate:</b><br><br>
Mediile industriale care implica greutati medii, de genul paletilor cu role, carucioare de scule, containere de transport marfa etc.<br>
