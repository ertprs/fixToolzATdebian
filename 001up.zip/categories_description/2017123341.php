<b>Caracteristici:</b><br><br>
Material furca: otel presat pana la 3 mm.<br>
Finisare furca: zincare.<br>
Fiting: tija filetata cu bucsa expandabila din plastic.<br>
Conform standardelor europene EN 12532.<br><br>

<b>Utilitate:</b><br><br>
Schele mobile cu inaltime de pana la 4 m pe suprafata stabila.<br>
