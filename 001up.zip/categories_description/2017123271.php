<b>Caracteristici:</b><br><br>
Material furca: otel presat pana la 4 mm.<br>
Finisare furca: zincare.<br>
Constructia robusta a acestui tip de roata permite eficienta sporita, durabilitate ridicata si performanta excelenta.<br>
Conform standardelor europene EN 12532.<br><br>

<b>Utilitate:</b><br><br>
Mediile industriale, ales pentru cele caracteristice traficului greu.<br>
