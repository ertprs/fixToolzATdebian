<b>Caracteristici:</b><br><br>
Material furca: otel presat de inalta calitate.<br>
Finisare furca: zincare, cu rezistenta ridicata la rugina.<br>
Constructia robusta a acestui tip de roata permite eficienta sporita, durabilitate ridicata si performanta excelenta.<br>
Conform standardelor europene EN 12532.<br><br>

<b>Utilitate:</b><br><br>
Mediile industriale orientate pe greutati medii, de genul containerelor de deseuri, carucioare de scule, containere de transport marfa etc.<br>
