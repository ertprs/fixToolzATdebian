<b>Caracteristici:</b><br><br>
Material furca: otel pana la 8 mm, capul pivotant fiind forjat.<br>
Finisare furca: vopsire (culoare neagra).<br>
Capul pivotant prezinta rulmenti din otel dur pentru o rezistenta ridicata la eforturile radiale si laterale.<br>
Niplurile de ungere sunt prezente pe toata suprafata furcii.<br>
Conform standardelor europene EN 12532/12533.<br><br>

<b>Utilitate:</b><br><br>
Industria chimica.<br>
Abatoare.<br>
Fabrici de textile.<br>