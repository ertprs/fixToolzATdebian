          <tr>
            <td>
              <div>
<a target="_blank" href="http://www.facebook.com/toolszone.ro"><img border="0" src="images/retele_sociale_01.png"></a><a target="_blank" href="http://twitter.com/ToolsZone/"><img border="0" src="images/retele_sociale_02.png"></a><a target="_blank" href="http://www.linkedin.com/pub/toolszone-ro-online-shop/1a/690/11b"><img border="0" src="images/retele_sociale_03.png"></a><a target="_blank" href="http://www.youtube.com/user/ToolsZone"><img border="0" src="images/retele_sociale_04.png"></a>
              </div>
            </td>
          </tr>
<?php
    include(DIR_WS_BOXES . 'spacing.php');
?>          <tr>
            <td>
              <div style="background-image: url(images/im.png);width:149px;padding-left:80px; padding-top:43px; padding-bottom:18px"><a href="ymsgr:sendIM?toolszone"><img border=0 src="http://opi.yahoo.com/online?u=ID&m=g&t=2"></a></div>
            </td>
          </tr>
<?php
    include(DIR_WS_BOXES . 'spacing.php');
?>