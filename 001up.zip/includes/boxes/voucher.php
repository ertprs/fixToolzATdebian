<?php
/*
  $Id: specials.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

?>
          <tr>
            <td>
           		<table border="0" width="100%" cellspacing="0" cellpadding="0">
           			<tr>
           				<td width="6"><?=tep_image("images/infobox/box2_left_top.gif")?></td>
           				<td class="box2BgTop" colspan="2">&nbsp;</td>
           				<td width="6"><?=tep_image("images/infobox/box2_right_top.gif")?></td>
           			</tr>
           			<tr>
           				<td class="box2BgLeft">&nbsp;</td>
           				<td class="box2Title">Voucher</td>
           				<td class="box2Title" align="right"><img src="images/icons/voucher.png"></td>
           				<td class="box2BgRight">&nbsp;</td>
           			</tr>
           			<tr>
           				<td class="box2BgLeft">&nbsp;</td>
           				<td class="box2Line" colspan="2">&nbsp;</td>
           				<td class="box2BgRight">&nbsp;</td>
           			</tr>
           			<tr>
           				<td class="box2BgLeft">&nbsp;</td>
           				<td class="box2" colspan="2">Voucher-ul valoric Toolszone.ro aduce clientilor nostri o reducere in plus fata de celelalte magazine din domeniu. Numarul nelimitat de vouchere puse la dispozitia utilizatorilor, ofera posibilitatea de a primi bonificatii in lei valabile pe site-ul nostru.<br><br><a href="<?=tep_href_link(FILENAME_VOUCHER, '', 'SSL')?>"><img src="images/icons/arrow.gif" alt="Voucher" title="Voucher" align="left" border="0" height="15" width="15">Recomanda ToolsZone.ro</a></td>
           				<td class="box2BgRight">&nbsp;</td>
           			</tr>
           			<tr>
           				<td width="6"><?=tep_image("images/infobox/box2_left_bottom.gif")?></td>
           				<td class="box2BgBottom" colspan="2">&nbsp;</td>
           				<td width="6"><?=tep_image("images/infobox/box2_right_bottom.gif")?></td>
           			</tr>
           		</table>
            </td>
          </tr>
<?php
    include(DIR_WS_BOXES . 'spacing.php');
?>