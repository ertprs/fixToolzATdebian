
<?php
 
  $specials_query_raw = "(select p.products_image, pd.products_name, p.products_id, p.products_price, p.products_tax_class_id, if( s.status, s.specials_new_products_price, null ) as specials_new_products_price from products_description pd, products p left join specials s on p.products_id = s.products_id, products_to_categories p2c where p.products_status = '1' and p.products_id = p2c.products_id and pd.products_id = p2c.products_id and pd.language_id = '1' and p.products_ordered > 0 order by products_ordered DESC, pd.products_name DESC LIMIT 0,9)";

  if ($random_product = tep_random_select($specials_query_raw)) {
?>
<!-- whats_new //-->
          <tr>
            <td>
<?php
 
    $info_box_contents = array();
    $info_box_contents[] = array('text' => "Cele mai vandute");

    new infoBoxHeading($info_box_contents, false, false, tep_href_link(FILENAME_BEST_SELLERS));

    if (tep_not_null($random_product['specials_new_products_price'])) {
      $whats_new_price = '<table width="100%"><tr><td colspan="2" class="old_price" style="font-size:12px"><s>' . $currencies->display_price($random_product['products_price'], tep_get_tax_rate($random_product['products_tax_class_id'])) . '</s></td></tr>';
      $whats_new_price .= '<tr><td class="price" valign="top">'.$currencies->display_price($random_product['specials_new_products_price'], tep_get_tax_rate($random_product['products_tax_class_id'])) . '</td><td width="100"><a href="' . tep_href_link(basename($PHP_SELF), tep_get_all_get_params(array('action')) . 'action=buy_now&products_id=' . $random_product['products_id']) . '">' . tep_image('images/icons/arrow.gif', IMAGE_BUTTON_BUY_NOW, '', '', 'align="left"') . ' Adauga in cos</a></td></tr></table>';
    } else {
      $whats_new_price  = '<table width="100%"><tr><td class="price">'.$currencies->display_price($random_product['products_price'], tep_get_tax_rate($random_product['products_tax_class_id'])).'</td><td width="100"><a href="' . tep_href_link(basename($PHP_SELF), tep_get_all_get_params(array('action')) . 'action=buy_now&products_id=' . $random_product['products_id']) . '">' . tep_image('images/icons/arrow.gif', IMAGE_BUTTON_BUY_NOW, '', '', 'align="left"') . ' Adauga in cos</a></td></tr></table>';
    }

    $info_box_contents = array();
    $info_box_contents[] = array('align' => 'left',
                                 'text' => '<center><a href="' . tep_href_link(FILENAME_PRODUCT_INFO, 'products_id=' . $random_product['products_id']) . '">' . tep_image(DIR_WS_IMAGES ."mari/". $random_product['products_image'], $random_product['products_name'], 130, 130) . '</a></center><a class="box_link" href="' . tep_href_link(FILENAME_PRODUCT_INFO, 'products_id=' . $random_product['products_id']) . '">' . $random_product['products_name'] . '</a><br>' . $whats_new_price);

    new infoBox($info_box_contents);
?>
            </td>
          </tr>
<!-- whats_new_eof //-->

<?php
    	include(DIR_WS_BOXES . 'spacing.php');
  }
?>
