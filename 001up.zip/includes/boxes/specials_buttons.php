          <tr>
            <td>
				<div style="height:42px;"><a href="<?=tep_href_link(FILENAME_SPECIALS)?>"><?=tep_image(DIR_WS_IMAGES . '/rightColumn/oferte.png')?></a></div>
				<div style="height:42px;"><a href="<?=tep_href_link(FILENAME_NEW_PRODUCTS)?>"><?=tep_image(DIR_WS_IMAGES . '/rightColumn/produseNoi.png')?></a></div>
				<div style="height:42px;"><a href="<?=tep_href_link(FILENAME_DEFAULT, 'cPath=0_2017123009') ?>"><?=tep_image(DIR_WS_IMAGES . '/rightColumn/soldari.png')?></a></div>
			</td>
		</tr>