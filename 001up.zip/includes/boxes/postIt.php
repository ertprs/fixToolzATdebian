<?php
/*
  $Id: specials.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

?>
          <tr>
            <td>
            	<div class="postIt">
				<table border="0" cellspacing="0" cellpadding="0">
           			<tr>
           				<td width="35" height="40" align="center"><?= tep_image('images/icons/index.gif')?></td>
           				<td><a  target="_blank" href="http://www.toolszone.ro/pdf/Dictionar-Tehnic-Englez-Roman.pdf">Index termeni tehnici</a></td>
           			</tr>
           			<tr>
           				<td align="center"><?= tep_image('images/icons/convertor.gif')?></td>
           				<td><a href="<?= tep_href_link(FILENAME_CONVERTOR) ?>">Convertor unitati de masura</a></td>
           			</tr>
           		</table>
           		</div>
            </td>
          </tr>
<?php
    include(DIR_WS_BOXES . 'spacing.php');
?>
