<?php
/*
  $Id: specials.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

?>
<script language="javascript">
	function checkEmail() {
		var email = document.getElementById('email');
		var filter = /^([a-zA-Z0-9_.-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;
		if (!filter.test(email.value)) {
			alert('Adresa de mail introdusa nu este valida.');
			email.focus
			return false;
		}else{
			document.incriere_newsletter.submit();
		}
	}
</script>
          <tr>
            <td>
	    <form name="incriere_newsletter" name="incriere_newsletter" action="<?=tep_href_link(FILENAME_SUBSCRIERE_NEWSLETTER, '', 'NONSSL', false)?>" method="POST">
		<table id="Table_01" width="229" height="71" border="0" cellpadding="0" cellspacing="0">
			<tr>
				<td colspan="5"><?= tep_image('images/subscriere_newsletter_01.png');?></td>
			</tr>
			<tr>
				<td colspan="3"><?= tep_image('images/subscriere_newsletter_02.png');?></td>
				<td rowspan="2"><a onClick="checkEmail()"><?= tep_image('images/subscriere_newsletter_03.png','Subscrie la Newsletter-ul ToolsZone.ro');?></a></td>
				<td rowspan="3"><?= tep_image('images/subscriere_newsletter_04.png');?></td>
			</tr>
			<tr>
				<td rowspan="2"><?= tep_image('images/subscriere_newsletter_05.png');?></td>
				<td><input type="text" style="width:158px; height:16; border:0px;font-size:10px" name="email" id="email"></td>
				<td rowspan="2"><?= tep_image('images/subscriere_newsletter_07.png');?></td>
			</tr>
			<tr>
				<td><?= tep_image('images/subscriere_newsletter_08.png');?></td>
				<td><?= tep_image('images/subscriere_newsletter_09.png');?></td>
			</tr>
		</table>
	    </form>
            </td>
          </tr>
<?php
    include(DIR_WS_BOXES . 'spacing.php');
?>