<?php
/*
  $Id: specials.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

?>

          <tr>
            <td>
              <script src="js/AC_RunActiveContent.js" type="text/javascript"></script>
              <script src="js/AC_ActiveX.js" type="text/javascript"></script>            
              <script type="text/javascript">
              AC_FL_RunContent( 'codebase','http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0','width','229','height','74','src','images/flash/comenzi-telefon','quality','high','pluginspage','http://www.macromedia.com/go/getflashplayer','movie','images/flash/comenzi-telefon' ); //end AC code
              </script><noscript><object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="229" height="74">
                <param name="movie" value="images/flash/comenzi-telefon.swf" />
                <param name="quality" value="high" />
                <embed src="images/flash/comenzi-telefon.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="229" height="74"></embed>
              </object></noscript>
              
            <!--  <img src="images/comenzi-telefon.png" />-->
	    </td>
          </tr>
<?php
    include(DIR_WS_BOXES . 'spacing.php');
?>