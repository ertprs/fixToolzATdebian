<table>
<tr>
<td><a href="" ><?=tep_image(DIR_WS_IMAGES . 'sclue_01.jpg')?></a></td>
<td><a href="" ><?=tep_image(DIR_WS_IMAGES . 'sclue_02.jpg')?></a></td>
<td><a href="" ><?=tep_image(DIR_WS_IMAGES . 'sclue_03.jpg')?></a></td>
<td><a href="" ><?=tep_image(DIR_WS_IMAGES . 'sclue_04.jpg')?></a></td>
</tr>
</table>