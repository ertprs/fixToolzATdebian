<?php
/*
  $Id: specials.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

?>
          <tr>
            <td>
           		<table border="0" width="100%" cellspacing="0" cellpadding="0">
           			<tr>
           				<td width="6"><?=tep_image("images/infobox/box2_left_top.gif")?></td>
           				<td class="box2BgTop">&nbsp;</td>
           				<td width="6"><?=tep_image("images/infobox/box2_right_top.gif")?></td>
           			</tr>
           			<tr>
           				<td class="box2BgLeft">&nbsp;</td>
           				<td class="box2Title">Fidelizare client</td>
           				<td class="box2BgRight">&nbsp;</td>
           			</tr>
           			<tr>
           				<td class="box2BgLeft">&nbsp;</td>
           				<td class="box2Line">&nbsp;</td>
           				<td class="box2BgRight">&nbsp;</td>
           			</tr>
           			<tr>
           				<td class="box2BgLeft">&nbsp;</td>
           				<td class="box2">
                   Pentru a demonstra inca odata sprijinul pe care Toolszone.ro doreste sa-l aduca clientilor sai,
                   pe langa produse de mare calitate si servicii ireprosabile, campania de fidelizare clienti incearca
                   sa stabileasca preturile cele mai accesibile din domeniu.<br>
                   <br><a href="http://www.toolszone.ro/how_i_order.php#facilitati"><img src="images/icons/arrow.gif" alt="Mai multe detalii" title="Mai multe detalii" align="left" border="0" height="15" width="15">Vezi mai multe detalii</a></td>
           				<td class="box2BgRight">&nbsp;</td>
           			</tr>
           			<tr>
           				<td width="6"><?=tep_image("images/infobox/box2_left_bottom.gif")?></td>
           				<td class="box2BgBottom">&nbsp;</td>
           				<td width="6"><?=tep_image("images/infobox/box2_right_bottom.gif")?></td>
           			</tr>
           		</table>
            </td>
          </tr>
<?php
    include(DIR_WS_BOXES . 'spacing.php');
?>