<?php

?>
<div class="bottom">
	<div class="bottom_center">
		<div ><center>
		<object width="1000" height="70">
			<param name="movie" value="images/flash/brands.swf">
			<embed src="images/flash/brands.swf" width="1000" height="70">
			</embed>
		</object>
		</center></div>
	</div>
</div>
<div class="bottom2">
	<div class="bottom_center">
		<div class="footer_brands">
			<table width="100%">
				<tr>
					<td width="20%" height="85" align="left" valign="top" style="color:#fff; font-weight: normal;">&nbsp;</td>
					<td width="20%" height="85" align="left" valign="top" style="color:#fff; font-weight: normal;">
            <a href="<?echo tep_href_link(FILENAME_TERMS);?>">Termeni si conditii</a><br>
            <a href="<?echo tep_href_link(FILENAME_CATEGORIES);?>">Lista categorii</a><br>
            <a href="<?echo tep_href_link(FILENAME_FAST_BUY);?>">Comanda rapida</a><br>
            <a href="<?echo tep_href_link(FILENAME_ACCOUNT);?>">Contul meu</a><br>
            <a href="<?echo tep_href_link(FILENAME_CONVERTOR);?>">Convertor</a>
          </td>
					<td width="20%" height="85" align="left" valign="top" style="color:#fff; font-weight: normal;">
            <a href="<?echo tep_href_link(FILENAME_HOW_I_ORDER);?>">Cum comand</a><br>
            <a href="<?echo tep_href_link(FILENAME_MANUFACTURERS);?>">Lista branduri</a><br>
            <a href="<?echo tep_href_link(FILENAME_CONTACT_US);?>">Contact</a><br>
            <a href="http://forum.toolszone.ro/">Forum</a><br>
            <a href="http://www.toolszone.ro/transactions.php">Securitatea Tranzactiilor</a>
          </td>
					<td width="20%" height="85" align="left" valign="top" style="color:#fff; font-weight: normal;">
            <a href="<?echo tep_href_link(FILENAME_ABOUT);?>">Despre noi</a><br>
            <a href="<?echo tep_href_link(FILENAME_SPECIALS);?>">Promotii	</a><br>
            <a href="http://www.toolszone.ro/how_i_order.php#facilitati">Fidelizare client</a><br>
            <a href="<?echo tep_href_link(FILENAME_NEW_PRODUCTS);?>">Produse noi</a><br>
            <a href="http://www.anpc.gov.ro" target="_blank">Protectia consumatorilor - A.N.P.C</a>
          </td>   
					<td width="20%" height="85" align="left" valign="top" style="color:#fff; font-weight: normal;">
            <a href="<?echo tep_href_link(FILENAME_DEFAULT);?>">Acasa</a><br>
            <a href="<?echo tep_href_link(FILENAME_DEFAULT, 'cPath=2017123009');?>">Solduri</a><br>
            <a href="<?echo tep_href_link(FILENAME_VOUCHER);?>">Voucher</a><br>
            <a href="<?echo tep_href_link(FILENAME_DEFAULT, 'cPath=1');?>">Catalog</a>
          </td>
				</tr>
				<tr>
					<td colspan="5" valign="bottom" align="center" style="color:#fff; font-weight: normal;">&copy; 2009 Virtual Tools SRL. Toate drepturile rezervate. Dezvoltat de: <a href="http://www.plus-design.eu">www.Plus-Design.eu</a></td>
				</tr>
			</table>
		</div>
	</div>	
</div>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-11900925-1");
pageTracker._trackPageview();
} catch(err) {}</script>