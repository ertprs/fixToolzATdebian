<?php
/*
  $Id: moneyorder.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_MONEYORDER_TEXT_TITLE', 'Ordin de Plata');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_DESCRIPTION', 'Dupa ce ati primit factura proforma pentru comanda dumneavoastra , puteti achita prin ordin de plata.<br><br><b>S.C. VIRTUAL TOOLS S.R.L.<br>C.I.F. RO25866810<br>J08/1193/07.08.2009</b><br><br><b>Banca:</b> PROCREDIT Sucursala Brasov<br><b>IBAN:</b> RO38MIRO0000317413440601 <br><br> In momentul in care primim confirmarea de plata, produsele vor fi livrate catre dumneavoastra.');
  define('MODULE_PAYMENT_MONEYORDER_TEXT_EMAIL_FOOTER', 'Dupa ce ati primit factura proforma pentru comanda dumneavoastra , puteti achita prin ordin de plata.<br><br><b>S.C. VIRTUAL TOOLS S.R.L.<br>C.I.F. RO25866810<br>J08/1193/07.08.2009</b><br><br><b>Banca:</b> PROCREDIT Sucursala Brasov<br><b>IBAN:</b> RO38MIRO0000317413440601 <br><br> In momentul in care primim confirmarea de plata, produsele vor fi livrate catre dumneavoastra.');
?>