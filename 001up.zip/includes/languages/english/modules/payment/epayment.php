<?php
/*
  $Id: epayment.php,v 1.00 2004/08/25 19:57:14 hpdl Exp $

  ePayment Module for osCommerce ( http://www.oscommerce.com)

  Copyright (c) 2004 GeCAD ePayment International

*/

  define('MODULE_PAYMENT_EPAYMENT_TEXT_TITLE', 'Carte de credit/debit prin ePayment');
  define('MODULE_PAYMENT_EPAYMENT_TEXT_DESCRIPTION', 'Procesarea comenzilor online cu carti de credit/debit se realizeaza prin intermediul GeCAD ePayment.');
  
?>