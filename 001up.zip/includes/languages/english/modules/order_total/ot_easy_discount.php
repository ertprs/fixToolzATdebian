<?php
  define('MODULE_EASY_DISCOUNT_TITLE', 'Easy Discount');
  define('MODULE_EASY_DISCOUNT_DESCRIPTION', 'Easy discount.');
?>