<?php
/*
  $Id$ ot_coupon.php language module

  Copyright (c) 2008 Club osCommerce www.clubosc.com

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_COUPON_TITLE', 'Voucher');
  define('MODULE_ORDER_TOTAL_COUPON_DESCRIPTION', 'Valoare Vocuher');
  define('TEXT_COUPON', 'Voucher');
?>
