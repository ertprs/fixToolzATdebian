<?php
/*
  $Id: ot_total.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_TOTAL_TITLE', 'Total');
  define('MODULE_ORDER_TOTAL_TOTAL_DESCRIPTION', 'Total Comanda');
?>