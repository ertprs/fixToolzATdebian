<?php
/*
  $Id: account.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Contul Meu');
define('HEADING_TITLE', 'Detalii Cont');

define('OVERVIEW_TITLE', 'Sumar');
define('OVERVIEW_SHOW_ALL_ORDERS', '(arata toate comenzile)');
define('OVERVIEW_PREVIOUS_ORDERS', 'Comenzi Precedente');

define('MY_ACCOUNT_TITLE', 'Contul Meu');
define('MY_ACCOUNT_INFORMATION', 'Vizualizeaza sau schimba informatile contului meu.');
define('MY_ACCOUNT_ADDRESS_BOOK', 'Vizualizeaza sau schimba adresele din agenda.');
define('MY_ACCOUNT_PASSWORD', 'Schimba parola.');

define('MY_ORDERS_TITLE', 'Comenzile mele');
define('MY_ORDERS_VIEW', 'Vizualizeaza comenzile efectuate.');

define('EMAIL_NOTIFICATIONS_TITLE', 'Notificatii E-Mail');
define('EMAIL_NOTIFICATIONS_NEWSLETTERS', 'Abonati-va sau dezabonati-va la newsletter.');
define('EMAIL_NOTIFICATIONS_PRODUCTS', 'Vizualizeaza sau schimba lista de produse pentru notificare.');
?>