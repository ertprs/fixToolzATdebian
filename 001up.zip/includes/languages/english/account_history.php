<?php
/*
  $Id: account_history.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Contul Meu');
define('NAVBAR_TITLE_2', 'Istoric');

define('HEADING_TITLE', 'Istoric Comenzi');

define('TEXT_ORDER_NUMBER', 'Comanda nr.:');
define('TEXT_ORDER_STATUS', 'Status Comanda:');
define('TEXT_ORDER_DATE', 'Data Comenzii:');
define('TEXT_ORDER_SHIPPED_TO', 'Livrat Catre:');
define('TEXT_ORDER_BILLED_TO', 'Facturat Catre:');
define('TEXT_ORDER_PRODUCTS', 'Produse:');
define('TEXT_ORDER_COST', 'Valoare Comanda:');
define('TEXT_VIEW_ORDER', 'Vizualizeaza Comanda');

define('TEXT_NO_PURCHASES', 'Nu ati achizitionat nimic');
?>
