<?php
/*
  $Id: address_book.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Contul Meu');
define('NAVBAR_TITLE_2', 'Agenda Adrese');

define('HEADING_TITLE', 'Agenda Mea de Adrese');

define('PRIMARY_ADDRESS_TITLE', 'Adresa Principala');
define('PRIMARY_ADDRESS_DESCRIPTION', 'Acesta adresa este utilizata ca si adresa preselectata pentru livrarea produselor si facturilor pentru comenzile plasate in cadrul acestui site web.<br><br>Deasemeni este utilizata ca si adresa de baza in calcularea tazelor pentru produse si servicii.');

define('ADDRESS_BOOK_TITLE', 'Agenda Lista Adrese');

define('PRIMARY_ADDRESS', '(adresa principala)');

define('TEXT_MAXIMUM_ENTRIES', '<font color="#ff0000"><b>NOTA:</b></font> Este permisa o lista de maxim %s adrese.');
?>
