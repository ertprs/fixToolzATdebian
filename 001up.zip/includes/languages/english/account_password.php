<?php
/*
  $Id: account_password.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Contul Meu');
define('NAVBAR_TITLE_2', 'Schimba Parola');

define('HEADING_TITLE', 'Parola Mea');

define('MY_PASSWORD_TITLE', 'Parola Mea');

define('SUCCESS_PASSWORD_UPDATED', 'Parola dvs. a fost updatat cu succes.');
define('ERROR_CURRENT_PASSWORD_NOT_MATCHING', 'Parola actuala nu se potriveste cu parola din registrul nostru. Va rugam sa mai incercati.');
?>
