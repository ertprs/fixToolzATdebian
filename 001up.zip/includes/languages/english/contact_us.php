<?php
/*
  $Id: contact_us.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Contact');
define('NAVBAR_TITLE', 'Contact');
define('TEXT_SUCCESS', 'Mesajul a fost trimis cu succes.');
define('EMAIL_SUBJECT', 'Mesaj de la ' . STORE_NAME);

define('ENTRY_NAME', 'Numele:');
define('ENTRY_EMAIL', 'Adresa de E-Mail:');
define('ENTRY_ENQUIRY', 'Mesaj:');
?>