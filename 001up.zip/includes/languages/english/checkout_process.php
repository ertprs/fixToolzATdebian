<?php
/*
  $Id: checkout_process.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('EMAIL_TEXT_SUBJECT', 'Procedura Comanda');
define('EMAIL_TEXT_ORDER_NUMBER', 'Comanda nr:');
define('EMAIL_TEXT_INVOICE_URL', 'Factura:');
define('EMAIL_TEXT_DATE_ORDERED', 'Data comenzii:');
define('EMAIL_TEXT_PRODUCTS', 'Produse');
define('EMAIL_TEXT_SUBTOTAL', 'Sub-Total:');
define('EMAIL_TEXT_TAX', 'Taxe:        ');
define('EMAIL_TEXT_SHIPPING', 'Transport: ');
define('EMAIL_TEXT_TOTAL', 'Total:    ');
define('EMAIL_TEXT_DELIVERY_ADDRESS', 'Adresa de livrare');
define('EMAIL_TEXT_BILLING_ADDRESS', 'Adresa de facturare');
define('EMAIL_TEXT_PAYMENT_METHOD', 'Modalitate de plata');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('TEXT_EMAIL_VIA', 'via');
?>