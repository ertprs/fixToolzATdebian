<?php
/*
  $Id: checkout_shipping_address.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Casa');
define('NAVBAR_TITLE_2', 'Schimbati adresa de transport');

define('HEADING_TITLE', 'Detakii livrare');

define('TABLE_HEADING_SHIPPING_ADDRESS', 'Adresa transporrt');
define('TEXT_SELECTED_SHIPPING_DESTINATION', 'Aceasta este adresa de transport selectata la care sa fie trimisa');
define('TITLE_SHIPPING_ADDRESS', 'Adresa Transport:');

define('TABLE_HEADING_ADDRESS_BOOK_ENTRIES', 'Agenda lista adrese');
define('TEXT_SELECT_OTHER_SHIPPING_DESTINATION', 'Va rugam sa selectati modalitatea de transport preferata pentru aceasta comanda.');
define('TITLE_PLEASE_SELECT', 'Va rugam selectati');

define('TABLE_HEADING_NEW_SHIPPING_ADDRESS', 'Adresa de transport noua');
define('TEXT_CREATE_NEW_SHIPPING_ADDRESS', 'Va rugam sa folositi formularul urmator pentru a crea o noua adresa de transport utilizata pentru aceasta comanda.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Mergeti mai departe');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'pentru a selecta modalitatea de transport preferata.');
?>
