<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Logout');
define('NAVBAR_TITLE', 'Logout');
define('TEXT_MAIN', 'Ai iesit din cont.<br><br>Cosul tau de cumparaturi a fost salvat.');
?>