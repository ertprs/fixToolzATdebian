<?php
/*
  $Id: account_newsletters.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Contul Meu');
define('NAVBAR_TITLE_2', 'Abonament Newsletter');

define('HEADING_TITLE', 'Abonament Newsletter');

define('MY_NEWSLETTERS_TITLE', 'Abonamentul Meu');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER', 'Newsletter General');
define('MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION', 'Include informatii despre produse noi, oferte speciale si anunturi promotionale.');

define('SUCCESS_NEWSLETTER_UPDATED', 'Abonamentul dvs. a fost updatat cu succes.');
?>
 