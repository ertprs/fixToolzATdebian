<?php
/*
  $Id: checkout_confirmation.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Casa');
define('NAVBAR_TITLE_2', 'Confirmare');

define('HEADING_TITLE', 'Confirmare Comanda');

define('HEADING_DELIVERY_ADDRESS', 'Adresa Livrare');
define('HEADING_SHIPPING_METHOD', 'Modalitate Transport');
define('HEADING_PRODUCTS', 'Produse');
define('HEADING_TAX', 'Taxe');
define('HEADING_TOTAL', 'Total');
define('HEADING_BILLING_INFORMATION', 'Detalii Facturare');
define('HEADING_BILLING_ADDRESS', 'Adresa Facturare');
define('HEADING_PAYMENT_METHOD', 'Modalitate Plata');
define('HEADING_PAYMENT_INFORMATION', 'Detalii Plata');
define('HEADING_ORDER_COMMENTS', 'Comentarii despre comanda');

define('TEXT_EDIT', 'Editeaza');
?>
