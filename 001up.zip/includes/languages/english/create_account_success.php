<?php
/*
  $Id: create_account_success.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Creaza un cont');
define('NAVBAR_TITLE_2', 'Succes');
define('HEADING_TITLE', 'Contul a fost creat!');
define('TEXT_ACCOUNT_CREATED', 'Felicitari! Contul a fost creat cu succes! Acuma va puteti loga in contul dumneavoastra. Daca aveti <small><b>orice</b></small> intrebare, va rugam sa ne contactati prin formularul nostru online <a href="' . tep_href_link(FILENAME_CONTACT_US) . '">aici</a>.<br><br>Un e-mail de confirmare a fost trimis la adresa dumneavoastra de e-mail.');
?>