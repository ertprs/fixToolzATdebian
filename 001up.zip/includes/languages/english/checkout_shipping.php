<?php
/*
  $Id: checkout_shipping.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'Casa');
define('NAVBAR_TITLE_2', 'Modalitate de transport');

define('HEADING_TITLE', 'Detalii livrare');

define('TABLE_HEADING_SHIPPING_ADDRESS', 'Adresa de transport');
define('TEXT_CHOOSE_SHIPPING_DESTINATION', 'Va rugam sa alegeti din lista adresa la care doriti sa fie livrate produsele.');
define('TITLE_SHIPPING_ADDRESS', 'Adresa Transport:');

define('TABLE_HEADING_SHIPPING_METHOD', 'Modalitate transport');
define('TEXT_CHOOSE_SHIPPING_METHOD', 'Va rugam sa selectati modalitatea de transport preferata pentru aceasta comanda.');
define('TITLE_PLEASE_SELECT', 'Va rugam selectati');
define('TEXT_ENTER_SHIPPING_INFORMATION', '');

define('TABLE_HEADING_COMMENTS', 'Va rugam sa introduceti un interval orar preferat pentru livrare.');

define('TITLE_CONTINUE_CHECKOUT_PROCEDURE', 'Mergeti mai departe');
define('TEXT_CONTINUE_CHECKOUT_PROCEDURE', 'pentru a selecta modalitatea de plata preferata.');
?>
