<?php
/*
  $Id: customers.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Clienti');
define('HEADING_TITLE_SEARCH', 'Cauta:');

define('TABLE_HEADING_FIRSTNAME', 'Prenume');
define('TABLE_HEADING_LASTNAME', 'Nume');
define('TABLE_HEADING_ACCOUNT_CREATED', 'Cont creat la data');
define('TABLE_HEADING_ACTION', 'Actiune');

define('TEXT_DATE_ACCOUNT_CREATED', 'Cont creat la data:');
define('TEXT_DATE_ACCOUNT_LAST_MODIFIED', 'Ultima modificare:');
define('TEXT_INFO_DATE_LAST_LOGON', 'Ultima logare:');
define('TEXT_INFO_NUMBER_OF_LOGONS', 'Numar de logari:');
define('TEXT_INFO_COUNTRY', 'Localitate:');
define('TEXT_INFO_NUMBER_OF_REVIEWS', 'Number of Reviews:');
define('TEXT_DELETE_INTRO', 'Esti sigur ca vrei sa stergi acest client?');
define('TEXT_DELETE_REVIEWS', 'Delete %s review(s)');
define('TEXT_INFO_HEADING_DELETE_CUSTOMER', 'Sterge client');
define('TYPE_BELOW', 'Scrie jos');
define('PLEASE_SELECT', 'Selecteaza unul');
?>
