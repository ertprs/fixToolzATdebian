<?php
/*
  $Id: sitemonitor.php,v 1.00 2006/09/24 by Jack_mcs

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  $cl_box_groups[] = array(
    'heading' => BOX_HEADING_SITEMONITOR,
    'apps' => array(
      array(
        'code' => FILENAME_SITEMONITOR_ADMIN,
        'title' => BOX_SITEMONITOR_ADMIN,
        'link' => tep_href_link(FILENAME_SITEMONITOR_ADMIN)
      ),
      array(
        'code' => FILENAME_SITEMONITOR_CONFIG_SETUP,
        'title' => BOX_SITEMONITOR_CONFIG_SETUP,
        'link' => tep_href_link(FILENAME_SITEMONITOR_CONFIG_SETUP)
      )
    )
  );
?>