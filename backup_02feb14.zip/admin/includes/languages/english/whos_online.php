<?php
/*
  $Id: whos_online.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Cine e online');

define('TABLE_HEADING_ONLINE', 'Online');
define('TABLE_HEADING_CUSTOMER_ID', 'ID');
define('TABLE_HEADING_FULL_NAME', 'Nume');
define('TABLE_HEADING_IP_ADDRESS', 'Adresa IP');
define('TABLE_HEADING_ENTRY_TIME', 'Ora intrarii');
define('TABLE_HEADING_LAST_CLICK', 'Ultimul click');
define('TABLE_HEADING_LAST_PAGE_URL', 'Ultimul URL');
define('TABLE_HEADING_ACTION', 'Actiune');
define('TABLE_HEADING_SHOPPING_CART', 'Cos cumparaturi');
define('TEXT_SHOPPING_CART_SUBTOTAL', 'Subtotal');
define('TEXT_NUMBER_OF_CUSTOMERS', 'La acest moment sunt %s clienti online');
?>