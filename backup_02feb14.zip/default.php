<table width="100%" height="60%" style="font-family:Verdana;">
<tr><td valign="middle" align="center">
<img src="images/logo.gif"><br><br><br>In curand
</td></tr></table>